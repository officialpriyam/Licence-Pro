## Packages
react-markdown | Rendering the setup guide documentation
date-fns | Formatting dates nicely

## Notes
Admin authentication uses cookie-based sessions via /api/admin/* endpoints
License verification is a public endpoint but mostly relevant for external apps
